package STPackage;

 


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import java.util.Collections;

import java.util.Scanner;

 

public class ScoreTrakker {
	
	private ArrayList<Student> studentList;
	private String[] files = {"scores.txt", "badscore.txt", "nofile.txt" };
	
	public ScoreTrakker() {
		super();
		this.studentList = new ArrayList <Student>();
	}
	
	public void loadDataFromFile(String fileName) throws FileNotFoundException {
		String tempName;
		String tempScoreS;
		int tempScoreI;
		
		FileReader reader = new FileReader(fileName);
		studentList = new ArrayList <Student>();
		
		//@SuppressWarnings("resource")
		Scanner in = new Scanner(reader);
		
		
		while(in.hasNextLine()) {
			tempName = in.nextLine();
			tempScoreS = in.nextLine();
			try {
				tempScoreI = Integer.parseInt(tempScoreS);
				Student student = new Student(tempName, tempScoreI);
				studentList.add(student);
			}
			catch(Exception NumberFormatException) {
				System.out.println("Incorrect format for " + tempName + " not a valid score: "+ tempScoreS);
			}
		}
		in.close();
	}
	
	public void printInOrder() {
		Collections.sort(studentList);
		System.out.println("Student Score List");
		for (Student s: studentList) {
			System.out.println(s.toString());
		}
		System.out.println("\n");
	}
	
	public void processFiles() {
		for(String fileName:files) {
			try {
				loadDataFromFile(fileName);
				printInOrder();
			}
			catch(Exception FileNotFoundExcetpion) {
				System.out.println("Can't open file: " + fileName);
			}
		}
	}
	
	public static void main(String[] args) throws IOException {
		ScoreTrakker trakker = new ScoreTrakker();

		trakker.processFiles();
	}
}